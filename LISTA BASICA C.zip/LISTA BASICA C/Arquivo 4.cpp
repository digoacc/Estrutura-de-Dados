#include<stdio.h>
#include<conio.h>
float n1, vendas, soma, final;
char nome;
main (){
	printf("Entre com o nome do vendedor: ");
	scanf("%s", &nome);
	printf("Salario fixo do vendedor: ");
	scanf("%f", &n1);
	printf("Valor das vendas que foram efetuadas pelo vendedor: ");
	scanf("%f", &vendas);
	soma=(vendas+0.15);
	final= (soma+n1);
	printf ("Relatorio final do vendedor: %s,e %f e mais %f de gorjeta", &nome, n1, final);
}
