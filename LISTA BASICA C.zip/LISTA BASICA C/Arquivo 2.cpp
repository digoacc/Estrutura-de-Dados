#include<stdio.h>;
#include<conio.h>;
float n1, n2, soma, subtracao, multiplicacao, divisao;
main(){
	printf("Entre com dois numeros: ");
scanf ("%f %f", &n1,&n2);
	soma=(n1+n2);
	subtracao=(n1-n2);
	multiplicacao=(n1*n2);
	divisao=(n1/n2);
	printf("O resultado das operacoes sao: %f %f %f %f", soma, subtracao, multiplicacao, divisao);
}
