#include<stdio.h>
#include<conio.h>
char comb;
float valordocarro,desconto,valor_pago,soma_desconto,soma_valor_pago;
main(){
valordocarro=1;	
soma_desconto=0;
while(valordocarro!=0){
printf("\n entre com o valor do carro:");
scanf("%f",&valordocarro);
printf("entre com o tipo de combustivel:");
scanf("%s",&comb);
if(comb=='A'){
desconto=(valordocarro*0.25);
valor_pago=(valordocarro-desconto);}
if(comb=='G'){
desconto=(valordocarro*0.21);
valor_pago=(valordocarro-desconto);}
if(comb=='D'){
desconto=(valordocarro*0.14);
valor_pago=(valordocarro-desconto);}
printf("o valor do desconto e:%f e o valor a ser pago e:%f",desconto,valor_pago);
soma_desconto=(soma_desconto+desconto);
soma_valor_pago=(soma_valor_pago+valor_pago);	
}
printf("o total da soma dos descontos e:%f",soma_desconto);
printf("o total da soma dos valores a serem pagos:%f",soma_valor_pago);	
}	

