#include <stdio.h>
int num;
main (){
	printf("Digite um numero: ");
	scanf("%d", &num);
	if(num>10){
		printf("Ele e maior");
	}
}
