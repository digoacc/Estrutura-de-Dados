#include<stdio.h>
#include<conio.h>
int i;
float sal,salm,quantsalm,reaj1,reaj2,reaj3,reaj4,totalreaj,totalreaj2,totalreaj3,totalreaj4,calfolha;
char nome;

main(){
for(i=1;i<=584;i++){
printf("Informe o nome do funcionario:");
scanf("%s",&nome);
printf("Informe o salario do funcionario:");
scanf("%f",&sal);
printf("Informe o valor do salario minimo:");
scanf("%f",&salm);
quantsalm=(sal/salm);
if(quantsalm<3){
reaj1=(sal*0,5);
totalreaj=(sal+reaj1);
printf("O salario do %s tera um reajuste de %.2f e passara a valer %.2f .\n",nome,reaj1,totalreaj);
}
if(3<quantsalm<=10){
reaj2=(sal*0,2);
totalreaj2=(sal+reaj2);
printf("O salario do %s tera um reajuste de %.2f e passara a valer %.2f .\n",nome,reaj2,totalreaj2);
}
if(10<quantsalm<=20){
reaj3=(sal*0,15);
totalreaj3=(sal+reaj3);
printf("O salario do %s tera um reajuste de %.2f e passara a valer %.2f .\n",nome,reaj3,totalreaj3);
}
else {
reaj4=(sal*0,1);
totalreaj4=(sal+reaj4);
printf("O salario do %s tera um reajuste de %.2f e passara a valer %.2f . \n",nome,reaj4,totalreaj4);
}
calfolha=(reaj1+reaj2+reaj3+reaj4);
printf("A empresa vai aumentar %.2f na sua folha de pagamento. \n");
}
}
