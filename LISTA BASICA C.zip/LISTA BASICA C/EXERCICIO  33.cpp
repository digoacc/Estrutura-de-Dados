#include<stdio.h>
#include<conio.h>
int n1,n2,n3;


main(){
printf("Informe um numero inteiro :");
scanf("%d",n1);
printf("Informe um numero inteiro :");
scanf("%d",n2);
printf("Informe um numero inteiro :");
scanf("%d",n3);
for((n1<n2+n3);(n2<n1+n3);(n3<n1+n2)){
if(n1==n2==n3){
printf("Os numeros formam um triangulo equilatero");
}
if((n1==n2) || ( n1==n3) || (n2==n3)){
printf("Os numeros formam um triangulo Isoceles");
}
if(n1!= n2!= n3){
printf("Os numeros formam um triangulo Isoceles");
}
}
}
	


