#include<stdio.h>
float C,fabrica,calculo,consumidor,soma;
main(){
printf("Entre com o valor de fabrica do carro: ");
scanf("%f", &C);
fabrica=(C*0.45);
calculo=(fabrica+C);
consumidor=(calculo*0.28);
soma=(calculo+consumidor);
printf("O valor final de fabrica sera: %.2f \n", calculo);
printf("O valor para venda sera: %.2f \n", soma);
}

