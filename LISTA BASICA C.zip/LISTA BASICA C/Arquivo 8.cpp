#include<stdio.h>
float D,C,calculo;
main(){
printf("Quantidade de dolares: ");
scanf ("%f", &D);
printf("Cotacao de dolar: ");
scanf ("%f", &C);
calculo=(D/C);
printf("A apresentcao do valor da conversao sera: %.2f ", calculo);
}
