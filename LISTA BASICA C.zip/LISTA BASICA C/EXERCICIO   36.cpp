#include<stdio.h>
#include<conio.h>
int tipo;
float kw,resul;

main(){
printf("Informe a quantidade de KWh mensal :");
scanf("%d",&kw);
printf("Informe o tipo do lugar 1 para Redidencia, 2 para comercio e 3 para industria :");
scanf("%d",&tipo);
if(tipo==1){
resul=(kw*0,6);
printf("O valor da sua conta vai ser de: %.2f \n",resul);
}
if(tipo==2){
resul=(kw*0,48);
printf("O valor da sua conta vai ser de: %.2f \n",resul);
}
if(tipo==3){
resul=(kw*1,29);
printf("O valor da sua conta vai ser de: %.2f \n",resul);
}
}


