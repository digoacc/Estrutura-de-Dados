#include<stdio.h>
#include<conio.h>
int niv;
float horas,r;


main(){
printf("Informe o nivel do professor :");
scanf("%d",niv);
printf("Informe a quantidade de horas trabalhadas :");
scanf("%f",horas);
if(niv==1){
r=(12*horas);
printf("O salario total desse professor vai ser de: %.2f",r);
}
if(niv==2){
r=(17*horas);
printf("O salario total desse professor vai ser de: %.2f",r);
}
if(niv==3){
r=(25*horas);
printf("O salario total desse professor vai ser de: %.2f",r);
}
}
	


