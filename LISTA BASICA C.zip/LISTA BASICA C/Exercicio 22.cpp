#include <stdio.h>
int i,custo,venda,calculo;
main(){
      for(i=1;i<=40;i++);{
      	printf("Entre com o pre�o de custo: ");
      	scanf("%d", &custo);
      	printf("Entre com o pre�o de venda: ");
      	scanf("%d", &venda);
      	if(custo>venda){
      		printf("Prejuizo");
			  }
      	if(venda==custo){
      		printf("Empate");
			  }
      	if(venda>custo){
      		printf("Lucro");
			  }
      	}
      }
