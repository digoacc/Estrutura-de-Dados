#include<stdio.h>
#include<conio.h>
int numeromes;


main(){
printf("Informe o numero de um mes de 1 a 12 :");
scanf("%d",numeromes);
if(numeromes==1){
printf("O mes informado e Janeiro .");
}
if(numeromes==2){
printf("O mes informado e Feveireiro .");
}
if(numeromes==3){
printf("O mes informado e Marco .");
}
if(numeromes==4){
printf("O mes informado e Abril .");
}
if(numeromes==5){
printf("O mes informado e Maio .");
}
if(numeromes==6){
printf("O mes informado e Junho .");
}
if(numeromes==7){
printf("O mes informado e Julho .");
}
if(numeromes==8){
printf("O mes informado e Agosto .");
}
if(numeromes==9){
printf("O mes informado e Setembro .");
}
if(numeromes==10){
printf("O mes informado e Outubro .");
}
if(numeromes==11){
printf("O mes informado e Novembro .");
}
if(numeromes==12){
printf("O mes informado e Dezembro .");
}
else{
printf("MES INVALIDO.");
}
}
