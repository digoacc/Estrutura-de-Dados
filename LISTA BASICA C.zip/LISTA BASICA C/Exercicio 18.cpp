#include <stdio.h>
int i,idade;
main(){
	for(i=1;i<=75;i++) {
		printf("Entre com a idade: ");
		scanf ("%d" , &idade);
		if(idade>=18){
		printf("Maior idade \n ");}
		if(idade<18){
		printf("Menor idade \n ");}
	}
}
