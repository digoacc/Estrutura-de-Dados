#include<stdio.h>
#include<conio.h>
float distancia1, combustivel1, consumomedio;
main(){
	printf("Digite a distancia percorrida pelo automovel: ");
	scanf ("%f", &distancia1);
	printf("Total de combustivel gasto: ");
	scanf ("%f", &combustivel1);
	consumomedio =(distancia1/combustivel1);
	printf("O consumo medio deste automovel foi de %f", consumomedio);
}
