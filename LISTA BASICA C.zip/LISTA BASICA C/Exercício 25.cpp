#include<stdio.h>
int num,num1;
main(){
printf("Entre com dois n�meros: ");
scanf("%d%d", &num,&num1);
if(num==num1){
	printf("Eles s�o iguais");
}
if(num>num1){
	printf("O n�mero %d � o maior", num);
}
if(num1>num){
	printf("O n�mero %d � o maior", num1);
}
}
