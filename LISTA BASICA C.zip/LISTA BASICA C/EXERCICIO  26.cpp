#include<stdio.h>
#include<conio.h>
int n,i;

main(){
	
for(i=1;i<=5;i++){
		
printf("Escreva um numero de um a cinco em forma numerica:");
scanf("%d",&n);
if(n==1){
printf("O numero digitado foi UM.\n");
}
if(n==2){
printf("O numero digitado foi DOIS.\n");
}
if(n==3){
printf("O numero digitado foi TRES.\n");
}
if(n==4){
printf("O numero digitado foi QUATRO.\n");
}
if(n==5){
printf("O numero digitado foi CINCO.");
}
}
	
}
