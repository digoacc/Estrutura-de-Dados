#include <stdio.h>
char nome,sexo,saude;
int idade,cont,cont2;
main (){
	idade=1;
	cont=0;
	cont2=0;
	while(idade!=0){
		printf("Entre com o nome: ");
		scanf("%s", &nome);
		printf("Entre com o sexo: 'f' ou 'm' ");
		scanf("%s", &sexo);
		printf("Entre com a idade: ");
		scanf("%d", &idade);
		printf("Entre com a saude: 'b' ou 'r' ");
		scanf("%s", &saude);
		if((sexo=='m')&&(idade>=18)&&(saude=='b')){
		printf("ESTA APTO! \n");
		cont=(cont+1);
    	}
    	else{
    		printf("NAO ESTA APTO! \n");
    		cont2=(cont2+1);
    	}
    }
	printf("As pessoas que estao aptas sao %d, e as que nao estao sao %d", cont,cont2);
}
