#include<stdio.h>
float custo,percentual,venda,final;
main(){
printf("Entre com o preco de custo do produto: \n");
scanf("%f", &custo);
printf("Enrei com o percentual de acrescimo para o valor final: \n");
scanf("%f", &percentual);
venda=(custo*percentual);
final=(venda+custo);
printf("O valor de venda sera: %.2f reais", final);
}
