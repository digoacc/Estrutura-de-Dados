#include<stdio.h>
#include<conio.h>
float numero1,numero2;

main(){
printf("Informe um numero:");
scanf("%f",numero1);
printf("Informe um numero:");
scanf("%f",numero2);
if(numero1==numero2){
printf("Os numeros sao iguais .");
}
if(numero1>numero2){
printf("Os Numeros sao diferentes e o  numero %f e maior do que o %f.",numero1,numero2);
}
if(numero1<numero2){
printf("Os numeros sao diferentes e o numero %f e maior do que o %f .",numero2,numero1);
}
}
