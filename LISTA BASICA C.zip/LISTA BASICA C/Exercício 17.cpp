#include <stdio.h>
int i, num, cont;
main (){
	cont=0;
	for (i=0;i<80;i++) {
		printf("Entre com um n�mero: ");
		scanf("%d", &num);
		if((num>=10)&&(num<=150)){
		cont=(cont+1);}
	}
	printf("A quantidade de n�meros que est�o no intervalo s�o: %d ", cont);
}

