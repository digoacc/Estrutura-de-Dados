#include<stdio.h>
float D,calcule;
main(){
printf("Entre com o valor depositado: ");
scanf("%f", &D);
calcule=(D+0,070);
printf("O rendimento apos um mes sera de: %.2f reais",calcule);
}
