#include <stdio.h>
int cont,conte,i;
char nome[20],sexo;
main(){
	cont=0;
	conte=0;
	for(i=1;i<=56;i++){
		printf("Entre com o nome da pessoa: ");
		scanf("%s", &nome);
		printf("Entre com o sexo do mesmo: ");
		scanf("%s", &sexo);
		if(sexo=='f'){
		printf("%s e mulher \n", &nome);
		cont=(cont+1);}
		if(sexo=='m'){
			printf("%s e homem \n", &nome);
			conte=(conte+1);}
		}
	}
