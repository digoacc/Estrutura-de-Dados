#include<stdio.h>
int numero;

main(){
	numero=1;
	while(numero!=0){
		printf("Entre com um n�mero: ");
		scanf("%d", &numero);
		if(numero==0){
			printf("Numero igual a zero \n");
		}
		if(numero>0){
			printf("Numero positivo \n");
		}
		if(numero<0){
			printf("Numero negativo \n");
		}
	}
}

