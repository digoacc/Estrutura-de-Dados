#include<stdio.h>
#include<conio.h>
int n1,n2,n3;


main(){
printf("Informe um numero :");
scanf("%f",n1);
printf("Informe um numero :");
scanf("%f",n2);
printf("Informe um numero :");
scanf("%f",n3);
if(n1<n2<n3){
printf("Os valores crescentes sao: %f , %f , %f ",n1,n2,n3);
}
if(n2<n1<n3){
printf("Os valores crescentes sao: %f , %f , %f ",n2,n1,n3);
}
if(n3<n1<n2){
printf("Os valores crescentes sao: %f , %f , %f ",n3,n1,n2);
}
if(n3<n2<n1){
printf("Os valores crescentes sao: %f , %f , %f ",n3,n2,n1);
}
if(n2<n3<n1){
printf("Os valores crescentes sao: %f , %f , %f ",n2,n3,n1);
}
if(n1<n3<n2){
printf("Os valores crescentes sao: %f , %f , %f ",n1,n3,n2);
}
}
	

