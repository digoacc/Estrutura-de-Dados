#include<stdio.h>
char o;
float n1,n2;
main(){
	printf("Entre com os dois numeros");
	scanf("%f%f",&n1,&n2);
	printf("entre com a operacao:'+'(adicao),'-'(subtracao),'*'(multiplicacao) ou '/'(divisao)");
	scanf("%s",&o);
	if(o=='+');{
		printf("a+b"a+b);
}
if(o=='-');{
	printf("a-b"a-b);
}
if(o=='*');{
	printf("a*b"a*b);
}
if(o=='/');{
	print("nao pode ser dividido por 0");}
}
