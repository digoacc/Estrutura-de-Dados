#include<stdio.h>
int num;
main(){
printf("Entre com o n�mero: ");
scanf("%d", &num);
if(num>80){
	printf("Maior que 80");
}
if(num==40){
	printf("Igual a 40");
}
if(num<25){
	printf("Menor que 25");
}
}
