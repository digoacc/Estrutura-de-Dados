#include<stdio.h>
#include<conio.h>
int ano,cont1,cont2;
float valor_carro,valor_desc,valor_pago;
char resp;
main(){
resp='Sim';
cont1=0;cont2=0;
while(resp!='Nao'){
printf("entre com valor do carro:");
scanf("%f",& valor_carro);
printf("entre com o ano do carro:");
scanf("%d",& ano);
if(ano<=2000){
valor_desc=(valor_carro*0,12);
valor_pago=(valor_carro-valor_desc);
cont1=cont1+1;}
else{
valor_desc=(valor_carro*0,07);
valor_pago=(valor_carro-valor_desc);}
cont2=cont2+1;}
printf("o valor do desconto e:%f",valor_desc);
printf("o valor a ser pago pelo carro e:%f",valor_pago);
printf("deseja continuar calculando os descontos do carro:'Sim'ou'Nao'");
scanf("%s",&resp);}
printf(("a quantidade de carros do ano 2000 e geral sao:%d%d",cont1,cont1+cont2));
}
