#include<stdio.h>
int num;
main(){
	printf("Entre com um valor: ");
	scanf("%d", &num);
	if((num>=100) && (num<=200)){
		printf("O numero %d esta entre 100 e 200", num);
	}
	if((num<=100) || (num>=200)){
		printf("O numero %d nao esta no intervalo pedido", num);
	}
}
