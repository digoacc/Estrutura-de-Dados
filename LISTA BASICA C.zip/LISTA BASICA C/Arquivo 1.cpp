//biblioteca
#include<stdio.h>
//biblioteca
#include<conio.h>
//declarar as vari�veis
int num1,num2,soma;
//iniciar o programa
main(){
//escreva=printf
printf("Entre com dois numeros: ");
//toda vari�vel � carregada pro "&" e a estrutura "%d" entre aspas
scanf("%d %d",&num1, &num2);
//= representa o sinal de atribui��o ":="
soma=(num1+num2);
//todo escreva/printf deve conter as aspas duplas, onde for carregar o dado voc� deve colocar o "%.." referente, caso no lugar de "soma" viesse uma vari�vel tipo char ele viria como "&nome", por exemplo.
printf("O resultado da soma e: %d",soma);
//final
}
//toda variavel que tem um tipo diferente deve ser separadas, como por exemplo: ("%d", num1); scanf("%s", &nome);
//toda linha de comando deve ser separado por ";"
//"\n" serve para pular a linha, como por exemplo ("Entre com dois numero: /n"), dai o lugar q vc vai inserir o dado ir� aparecer na proxima linha, ao inv�s de aparecer na mesma linha do que se pede.//
