#include <stdio.h>
int num1,num2;
main (){
	printf("Entre com dois numeros: ");
	scanf("%d%d", &num1, &num2);
	if(num1>num2){
	printf("N�mero %d e maior",num1);
	}
	if(num2>num1){
		printf("Numero %d e maior",num2);
	}
}
