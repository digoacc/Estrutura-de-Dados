#include<stdio.h>
float C,calcule;
main(){
printf("Entre com a temperatura em graus Celsius: ");
scanf("%f", &C);
calcule=((9*C+160)/5);
printf("O resultado da temperatura em Fahrenheit e: %.2f",calcule);
}
