#include<stdio.h>
float compra,calcule;
main(){
printf("Entre com o valor da compra: ");
scanf("%f", &compra);
calcule=(compra/5);
printf("O valor das parcelas sera de: %.2f reais", calcule);
}
