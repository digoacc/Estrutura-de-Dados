#include<stdio.h>
int A,B,troca;
main (){
printf("Entre com dois valores para A e B: ");
scanf("d%d%",&A,&B);
troca=A;
A=B;
B=troca;
printf("A troca dos valores sao %d %d",A,B);
}
