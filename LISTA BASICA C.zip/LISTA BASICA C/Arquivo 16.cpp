#include<stdio.h>
float A,B,C,calcule;
char nome;
main(){
	printf("Entre com o nome do aluno: ");
	scanf("%s", &nome);
	printf("Entre com as tres notas do aluno: ");
	scanf("%f%f%f", &A,&B,&C);
	calcule=((A+B+C)/3);
	if(calcule>=7){
		printf("O aluno %s foi aprovado", &nome);
	}
	if(calcule<=5){
		printf("O aluno %s nao foi aprovado", &nome);
	}
	}

