#include<stdio.h>
#include<conio.h>
int id;



main(){
printf("Informe a idade do nadador :");
scanf("%d",&id);
if((id>=5) && (id<=7)){
printf("Infantil A. ");
}
if((id>=8) && (id<=10)){
printf("Infantil B. ");
}
if((id>=11) && (id<=13)){
printf("juvenil A. ");
}
if((id>=14) && (id<=17)){
printf("juvenil B. ");
}
if((id>=18) && (id<=25)){
printf("Senior. ");
}
else{
printf("IDADE FORA DA FAIXA ETARIA.");
}
}
	


