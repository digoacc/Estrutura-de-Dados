//List 2 - ex 9
//Aluno: Rodrigo Almeida
#include<stdio.h>
int main(){
	int i;
	
	for(i=1000; i<=2000; i++){
		if(i%11==5){
			printf("%i,", i);
		}
	}
	
}
