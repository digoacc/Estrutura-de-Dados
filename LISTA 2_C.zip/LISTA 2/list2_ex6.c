//Lista 2 - Exerc�cio 
//Aluno: Rodrigo Almeida
#include<stdio.h>
main(){
	int j;
	
	do{
		printf("*****************\n");
		printf("*GAME OF THRONES*\n");
		printf("*****************\n");
		printf("[1] Jogar.\n");				//MENU
		printf("[2] Carregar jogo.\n");
		printf("[3] Creditos.\n");
		printf("[4] Sair do jogo.\n");
		printf("Escolha uma das opcoes acima: ");
		scanf("%d", &j);
		printf("\n");
		
		if(j==1){
			printf("Parabens, voce morreu.\n\n");
		}
		if(j==2){
			printf("Voce nao possui dados salvos para carregar.\n");
		}
		if(j==3){
			printf("O jogo baseado em uma serie de televisao, onde todo mundo morre, ate mesmo voce.\n");
		}
		
	}while(j!=4);

return 0;
}
