//Lista 2 ex 10
//Aluno:Rodrigo Almeida
#include<stdio.h>
int main(){
	int i;
	
	for(i=1; i<=100; i++){
		if(i%4==0){
			printf("plim,");
		}else{
			printf("%i,", i);
		}
	}
}
