//Lista 2 - exercicio 3
//Aluno: Rodrigo Jos� de Almeida
#include<stdio.h>
#include<string.h>

int main(){
	int esc1, esc2;
	char card1[10], card2[10];
	
	printf("Escolha o Naipe de sua carta:\n");
	printf("-------[1]- Copas   -------\n");
	printf("-------[2]- Paus    -------\n");
	printf("-------[3]- Espadas -------\n");
	printf("-------[4]- Ouro    -------\n");
	scanf("%i", &esc1);
	
	if(esc1>=1 && esc1<=4){
		if(esc1==1){
			strcpy(card1, "Copas");
		}
		if (esc1==2){
			strcpy(card1, "Paus");
		}
		if(esc1==3){
			strcpy(card1, "Espadas");
		}
		if(esc1==4){
			strcpy(card1, "Ouros");
		}
	}else{
		printf("Escolha um numero entre 1 e 4.");
	}
	
	printf("Escolha o valor de sua carta\n");
	printf("[1]-As     [2]-Dois    [3]-Tres\n");
	printf("[4]-Quatro [5]-Cinco   [6]-Seis\n");
	printf("[7]-Sete   [8]-Oito    [9]-Nove\n");
	printf("[10]-Dez   [11]-Valete [12]Dama\n");
	printf("[13]Rei.\n");
	scanf("%i", &esc2);
	
	if(esc2>=1 && esc2<=13){
		if(esc2==1){
			strcpy(card2, "As");
		}
		if(esc2==2){
			strcpy(card2, "Dois");
		}
		if(esc2==3){
			strcpy(card2, "Tres");
		}
		if(esc2==4){
			strcpy(card2, "Quatro");
		}
		if(esc2==5){
			strcpy(card2, "Cinco");
		}
		if(esc2==6){
			strcpy(card2, "Seis");
		}
		if(esc2==7){
			strcpy(card2, "Sete");
		}
		if(esc2==8){
			strcpy(card2, "Oito");
		}
		if(esc2==9){
			strcpy(card2, "Nove");
		}
		if(esc2==10){
			strcpy(card2, "Dez");
		}
		if(esc2==11){
			strcpy(card2, "Valete");
		}
		if(esc2==12){
			strcpy(card2, "Dama");
		}
		if(esc2==13){
			strcpy(card2, "Rei");
		}
	}else{
		printf("Escolha um numero entre 1 e 13");
	}
	printf("Voce escolheu a carta: %s de %s.", card2, card1);
	
	
return 0;
}

