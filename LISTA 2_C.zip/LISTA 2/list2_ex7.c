//Lista 2 - ex 7
//Aluno:Rodrigo Almeida
#include<stdio.h>
int main(){
	float i, n;
	float maior=-9999, menor=9999;
	
	for(i=0; i<15; i++){
		printf("Digite um numero:");
		scanf("%f", &n);
		
		if(n>maior){
			maior=n;
		}
		if(n<menor){
			menor=n;
		}
	}
	printf("\n\n");
	printf("Maior numero: %1.0f\n", maior);
	printf("Menor numero: %1.0f", menor);
}
