//Lista 2 - ex5
//Aluno: Rodrigo Almeida
#include<stdio.h>

int main(){
	
	int num;
	
	printf("Toque em 0 para terminar o codigo.");
	printf("\n\n\n");
	
	do{
		printf("Pressione um numero inteiro:");
		scanf("%d", &num);
		
		if(num>=0){  //POSITIVO OU NEGATIVO
			printf("O numero %d e positivo.\n", num);
		} else{
			printf("O numero %d e negativo.\n", num);
		}
		if(num%2==0){ //PAR OU IMPAR
			printf("O numero %d e par.\n", num);
		} else{
			printf("O numero %d e impar.\n", num);
		}
		printf("\n\n");
		
	}while(num !=0);
return 0;
}
