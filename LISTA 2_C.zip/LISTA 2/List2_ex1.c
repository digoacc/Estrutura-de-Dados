//Lista 2 exerc�cio 1.
//Aluno:Rodrigo Almeida
#include<stdio.h>
#include<stdlib.h>
main(){
	int n1, n2,soma;
	int esc1;
	char j1[10], j2[10];
	
	printf("Digite o nome do jogador 1: \n");
	scanf(" %s", j1);
	
	printf("Digite o nome do jogador 2: \n");
	scanf(" %s", j2);
	
	printf("Jogador 1 escolha (1)-impar ou (2)-par:\n");
	scanf("%i", &esc1);
		if(esc1==1){
			printf("JOGADOR 1:IMPAR \nJOGADOR 2:PAR \n");
		}else{
			printf("JOGADOR 1:PAR \nJOGADOR 2:IMPAR \n\n");
		}
	
	printf("Jogador 1, digite um numero entre 0 e 5: \n");
	scanf("%i", &n1);
	
	printf("Jogador 2, digite um numero entre 0 e 5: \n");
	scanf("%i", &n2);
	
	soma=(n1+n2);
	
	if((soma%2==0) && (esc1=2)){
		printf("JOGADOR 1 GANHOU");
	}else{
		printf("JOGADOR 2 GANHOU");
	}
	printf("\n\n\n\n\n");
	
	printf("--------------JOGO DE PAR OU IMPAR-------------\n");
	printf("Nome do Jogador 1:%s.\n", j1);
	printf("Nome do Jogador 2:%s.\n", j2);
	if(esc1==1){
		printf("Jogador 1 escolheu Impar.\n");
		printf("Jogador 2 escolheu Par.\n");
	}else{
		printf("Jogador 1 escolheu Par.\n");
		printf("Jogador 2 escolheu Impar.\n");
	}

	getch();
	return 0;
	
}
