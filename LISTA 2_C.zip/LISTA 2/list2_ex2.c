//Lista 2 - exerc�cio 1
//Aluno:Rodrigo Almeida
#include<stdio.h>
main(){
	char j1[20],j2[20];
	int opc1,opc2;
	
	printf("Digite o nome do Jogador 1:\n");
	scanf("%s", j1);
	
	printf("Digite o nome do Jogador 2:\n");
	scanf("%s", j2);
	printf("\n\n");
	printf("Jogador 1. Escolha 1-Pedra, 2-Papel ou:3-Tesoura:\n");
	scanf("%i", &opc1);
	printf("Jogador 2. Escolha 1-Pedra, 2-Papel ou:3-Tesoura:\n");
	scanf("%i", &opc2);
	
	if((opc1==1) && (opc2==1)){
		printf("Os Jogadores empataram\n");
	}
	if((opc1==1) && (opc2==2)){
		printf("O Jogador 2 ganhou\n");
	}
	if((opc1==1) && (opc2==3)){
		printf("O Jogador 1 ganhou\n");
	}
	if((opc1==2) && (opc2==1)){
		printf("O Jogador 1 ganhou\n");	
	}
	if((opc1==2) && (opc2==2)){
		printf("Os Jogadores empataram\n");
	}
	if((opc1==2) && (opc2==3)){
		printf("O Jogador 2 ganhou\n");
	}
	if((opc1==3) && (opc2==1)){
		printf("O Jogador 2 ganhou\n");
	}
	if((opc1==3) && (opc2==2)){
		printf("O Jogador 1 ganhou\n");
	}
	if((opc1==3) && (opc2==3)){
		printf("Os Jogadores empataram\n");
	}
	getch();
return 0;	
}
