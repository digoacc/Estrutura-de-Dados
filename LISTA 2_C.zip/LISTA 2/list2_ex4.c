//Lista 2 - ex 4
//Aluno: Rodrigo Almeida
#include<stdio.h>
#include<string.h>
int main(){
	int i=0;
	int c=0;
	
	
	for(i=0; i<=99; i++){
		printf("%d,", i);
			
		if(i==99){
			printf("\b.");
		}	
		c++; //contador
		if(c==10){
			printf("\n");
			c=0;
		}
	
	}
	
	
return 0;			
}
