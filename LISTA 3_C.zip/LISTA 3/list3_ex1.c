//lista3 ex1
//aluno: Rodrigo Almeida
#include<stdio.h>
#include<string.h>
#include<locale.h>

int main(){
	int i, n1, n2;
	srand(time(NULL));
	setlocale(LC_ALL,"");
	
	printf("N�meros aleat�rios entre 0 e 100:\n");
	n1 = ( rand() % 100 );
	do{
		n2 = (n1 + rand() % 100);
	}while(n2>100);
	printf("Numero 1 = %i\n",n1);
	printf("Numero 2 = %i\n",n2);
	printf("Intervalo: ");
	for (i=n1+1; i<n2; i++){
		printf("%i, ",i);
	}
	printf("\b\b.");
		
	return 0;
	
	
}
