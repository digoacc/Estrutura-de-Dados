//lista3 ex5
//aluno: Rodrigo Almeida
#include<stdio.h>
#include<string.h>

int main(){
	int i, n;
	int c = 1;
	
	srand(time(NULL));
	
	printf("Numeros aleatorios entre 0 a 99.\n");	
	for(i=1; i<101; i++){
		n = (rand() % 99);
		printf("%3d, ",n);
		c = c + 1;
		if (c>10){
			if(i==100){
				printf("\b\b.");
			}
			printf("\n");
			c = 1;
		}
		if(i==100){
			printf("\b.");
		}
	}
return 0;
}
