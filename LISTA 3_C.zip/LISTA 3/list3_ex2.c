//lista3 ex2
//aluno: Rodrigo Almeida
#include<stdio.h>
int main(){
	int i,n,unidade,dezena,centena,milhar;
	
	srand(time(NULL));
	n = 1000 + rand() % 9000 - 1;
	
		printf("o numero:%i \n",n);
		
		milhar = (n / 1000)*1000;
		printf("%i,   \n", milhar);
		
		dezena = (n /100)% 10 ;
		printf("%i00,   \n", dezena);
	
	
		dezena =(n%100) / 10;
		printf("%i0,   \n", dezena);
	
		unidade =(n%100) %10;
		printf("%i,   \n", unidade);
		
	return 0;
}
