//lista3 ex4
//aluno: Rodrigo Almeida
#include<stdio.h>
int main(){
	int i, n;
	srand(time(NULL));
	
	for(i=0; i<100; i++){
		n=-100 + rand() % 200;
		printf("%d|", n);
	}
return 0;
}
