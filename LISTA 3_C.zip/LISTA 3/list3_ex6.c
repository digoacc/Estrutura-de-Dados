//lista3 ex6
//aluno: Rodrigo Almeida
#include<stdio.h>
#include<string.h>
int main(){
	int i, n;
	srand(time(NULL));
	
	for(i=0; i<100; i++){
		n=-100 + rand() % 200;
		printf("%3d : ", n);
		if(n<0){
			printf("Este numero e negativo ");
		}else{
			printf("Este numero e positivo ");
		}
		if(n%2==0){
			printf("e par.\n");
		}else{
			printf("e impar.\n");
		}
	}
return 0;
}
