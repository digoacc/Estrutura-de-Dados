//lista3 ex3
//aluno: Rodrigo Almeida
#include<stdio.h>
int main(){
	int i, n, x;
	srand(time(NULL));
	
	printf("TABUADA DE UM NUMERO ALEATORIO\n");
	n = 1 + rand() % 10;
	printf("Numero %d.\n", n);
	
	for(i=0; i<10; i++){
		x=i*n;
		printf("%d x %d = %d\n", n,i,x);
	}
}
