//lista3 ex7
//aluno: Rodrigo Almeida
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char j1[10], j2[11]={"Computador"};
	int esc1, n1, n2, soma;
	
	srand(time(NULL));
	
	printf("Jogo do Par ou Impar(SINGLE PLAYER).\n");
	printf("------------------------------------\n");
	printf("Jogador 1, insira seu nome:\n");
	scanf("%s", j1);
	printf("Jogador 1 : %s\n", j1);
	printf("Jogador 2 : %s\n", j2);
	printf("------------------------------------\n");
	
	printf("Jogador 1, pressione [1]-PAR ou [2]-IMPAR.\n");
	scanf("%d", &esc1);
		if (esc1==1){
			printf("%s : PAR\n%s : IMPAR\n",j1,j2);
			printf("-------------------------------\n");
		}else{
			printf("%s : IMPAR\n%s : PAR\n",j1,j2);
			printf("-------------------------------\n");
		}
		
	printf("Jogador 1 escolha um numero de 0 a 5:\n");
	scanf("%d", &n1);
	n2= rand() % 5;
	printf("Jogador 1: %d\nComputador : %d\n",n1,n2);
	printf("------------------------------------\n");
	soma = n1+n2;
	printf("Soma dos Valores:%d.\n", soma);
	
		if (esc1 == 1){
			if (soma % 2 == 0){
				printf("%s Ganhou!",j1);
			}else{
				printf("%s Ganhou!",j2);
			}		
		}else{
			if (soma % 2 == 0){
				printf("%s Ganhou!",j2);
			}else{
				printf("%s Ganhou!",j1);
			}		
		}
return 0;	
}
