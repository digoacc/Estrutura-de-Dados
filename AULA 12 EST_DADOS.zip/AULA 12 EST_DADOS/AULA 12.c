#include<stdio.h>
int main(){
	int i, j, k;	// i sao as linhas
					// j sao as colunas		
	int matriz[4][4];
	printf("Matriz original\n");
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			matriz[i][j] = rand()%10;
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - metade superior\n");
	for(i = 0; i < 2; i++){
		for(j = 0; j < 4; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - metade inferior\n");
	for(i = 2; i < 4; i++){
		for(j = 0; j < 4; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - metade esquerda\n");
	for(i = 0; i < 4; i++){
		for(j = 0; j < 2; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - metade direita\n");
	for(i = 0; i < 4; i++){
		for(j = 2; j < 4; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("Matriz original\n");
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - espelhada horizontalmente\n");
	for(i = 0; i < 4; i++){
		for(j = 3; j >= 0; j--){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\nMatriz - espelhada verticalmente\n");
	for(i = 3; i >= 0; i--){
		for(j = 0; j < 4; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
return 0;
}
