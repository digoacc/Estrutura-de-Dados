#include<stdio.h>
int main(){
	int num, i, j;
	char gods[4][10] = {"ra", "zeus", "poseidon", "belona"};

	FILE *chinelinho; //criar um ponteiro do tipo arquivo

	chinelinho = fopen("index.html","w");
	fprintf(chinelinho, "%s", "<html>\n");
	
	for(i = 0; i < 4; i++){
		fprintf(chinelinho, "<div class=\"%s\"></div>\n", gods+i);		
	}
	
	fprintf(chinelinho, "%s", "</html>");
	
	fclose(chinelinho);
	
	return 0;
}
