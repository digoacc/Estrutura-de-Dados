#include<stdio.h>

int main(){
	int num, i, j;
	int quad[5][5];
	char gods[10] = {'g','o','d','s'};
	//trabalhando com arquivos em C
	
	FILE*chinelinho; //criar um ponteiro do tipo arquivo
	
	//abrir/criar o arquivo
	//modos de abertura
	//r leitura
	//w escrita
	//a append(adicionar)
	chinelinho=fopen("boanoite.txt", "w");
	
	//escrever no arquivo
	for(num=0; num<10; num++){
		fprintf(chinelinho, "<div class=%s></div>\n", gods);
	}
	//for(i=0; i<5; i++){
		//for(j=0;j<5;j++){
			//quad[i][j]=1;
			//fprintf(chinelinho, "%d", quad[i][j]);
	//	}
	//	fprintf(chinelinho, "\n");
//	}
	//fechar o arquivo
	fclose(chinelinho);
	
return 0;
}
