// Lista 01 - Exercicio 2
// Aluno:Rodrigo Jos� de Almeida

#include<stdio.h>
#include<stdlib.h>

main(){
	
	float vida, ataque, defesa;
	float media;
	
	printf("--------Criando um mago--------\n");
	printf("Vida do mago: \n");
	scanf("%f", &vida);
	printf("Ataque do mago: \n");
	scanf("%f", &ataque);
	printf("Defesa do mago: \n");
	scanf("%f", &defesa);
	printf("\n\n");
	
	media=((vida+ataque+defesa)/3);
	printf("Sua XP e:%.2f\n", media);
	
	if(media<=25){
		printf("Voce e novato.\n");
	}
	if((media>25) && (media<=50)){
		printf("Voce e um mago.\n");
	}
	if((media>50) && (media<=75)){
		printf("Voce e um mago supremo.");
	}
	if(media>75){
		printf("Voce e o Lorde Das Magias.");
	}	
return 0;	
}
