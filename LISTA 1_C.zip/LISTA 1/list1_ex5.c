//Lista 1 exerc�cio 5
//Rodrigo Almeida
#include<stdio.h>
main(){
	int j1;
	
	printf("*********************\n");
	printf("*   Jogo da pinga   *\n");
	printf("*********************\n");
	printf("Voce esta cercado por bebidas, voce deve beber uma delas para prosseguir.\n");
	printf("1-Aguardente 51.\n");
	printf("2-Vodka Orloff.\n");
	printf("3-Whisky Red Label.\n");
	printf("4-Tequila Jose Cuervo.\n");
	printf("5-Absinto Hapsburg.\n");
	printf("Digite o numero da bebida desejada:\n");
	scanf("%d", &j1);
	
	if(j1==1){
		printf("Voce tomou a pinga 51,apagou e foi encontrado no dia seguinte num banco de uma praca.");
	}
	if(j1==2){
		printf("Voce tomou a Orloff e saiu em busca de aventuras.");
	}
	if(j1==3){
		printf("Voce tomou o Red Label e foi para o hospital.");
	}
	if(j1==4){
		printf("Voce tomou a Jose Cuervo, achou que era o superman e pulou de um predio.");
	}
	if(j1==5){
		printf("Voce tomou o Hapsburg e queria ir pra narnia pelo guarda roupa.");
	}
	
return 0;	
}
