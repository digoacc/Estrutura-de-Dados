#include<stdio.h>
main (){
	int num;
	
	printf("Digite um numero inteiro: ");
		scanf("%i" ,&num);
		
	if((num>100) && (num<200)){
		printf("Voce digitou um numero entre 100 e 200.");
	}else{
		printf("Voce digitou um numero fora da caixa");
	}
	
}
