//Lista 1- exercicio 4
//Rodrigo Almeida
#include<stdio.h>
main(){
	int vit,der,emp;
	char nome;
	
	printf("Digite o nome da equipe:\n");
	scanf("%s",&nome);
	printf("Digite as vitorias:");
	scanf("%i", &vit);
	printf("Digite as derrotas:");
	scanf("%i", &der);
	printf("Digite os empates:");
	scanf("%i", &emp);
	
	
return 0;
}
