//Lista 1 - exerc�cio 3
//Aluno: Rodrigo Almeida
#include<stdio.h>
main(){
	char eq1[10],eq2[10];
	int vit,der,emp;
	int soma;
	
	printf("Digite a equipe 1: ");
	scanf(" %s",eq1);
	printf("Vitorias: ");
	scanf("%i",&vit);
	printf("Derrotas: ");
	scanf("%i",&der);
	printf("Empates: ");
	scanf("%i",&emp);
	
	soma=((vit*3)+(emp));
	printf("Pontos totais da equipe: %i\n",soma);
	
	printf("-------------------------------------\n");
	
	printf("Digite a equipe 2: ");
	scanf(" %s",eq2);
	printf("Vitorias: ");
	scanf("%i",&vit);
	printf("Derrotas: ");
	scanf("%i",&der);
	printf("Empates: ");
	scanf("%i",&emp);
	
	soma=((vit*3)+(emp));
	printf("Pontos totais da equipe: %i\n",soma);

return 0;	
}
